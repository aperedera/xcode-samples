//
//  c_code.c
//  unsafe_conversions
//
//  Created by Anatoli on 10/29/15.
//  Copyright © 2015 Anatoli. All rights reserved.
//

#include "c_code.h"
#include <time.h>

/**
 * Create an APIStruct to give to a callback
 */
APIStruct getAPIStruct()
{
    APIStruct retVal;
    retVal.time = time(0);
    retVal.stats[0] = 120;
    retVal.stats[1] = 121;
    retVal.stats[2] = 122;
    retVal.compoundValueOld = 23456;
    
    return retVal;
}

/**
 * Invoke a callback that takes APIStruct *
 */
void invokeCallBack( my_cb_t cb )
{
    APIStruct x = getAPIStruct();
    cb( &x );
}

/**
 * Invoke a callback that takes an APIStruct via void *
 */
void invokeCallBackVoid( my_cbv_t cb )
{
    APIStruct x = getAPIStruct();
    cb( &x );
}

/**
 * Helper to get an APIStruct from void *
 */
APIStruct getStructFromVoid( void * _p )
{
    return *(APIStruct*)_p;
}