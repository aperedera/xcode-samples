//
//  swift_code.swift
//  unsafe_conversions
//
//  Created by Anatoli on 10/29/15.
//  Copyright © 2015 Anatoli. All rights reserved.
//

/**
 * This is our native Swift structure.
 *
 * In C you can pack structures for different alignment.  We do this in c_code.h. 
 * If #pragma pack(2) is used, then the unsafe conversion, i.e. casting 
 * UnsafeMutablePointer<Void> to UnsafeMutablePointer<MyStruct> and using .memory
 * to get MyStruct, will yield corrupted data.
 *
 * This structure is handy to use when callbacks take APIStruct *, as is or
 * as void *, as an IN parameter, i.e. the pointer is not used to send info
 * back to the C code.  If it's an INOUT parameter and we need to modify it 
 * to communicate back to C, then MyStructUnsafe can be used, with the 
 * disadvantage that we have to worry more about object lifetime.
 */
struct MyStruct
{
    init( _apis : APIStruct)
    {

        revision = _apis.revision
        client = _apis.client
        cmd = _apis.cmd
        parameter = _apis.parameter
        value = _apis.value
        time = _apis.time
        stats = _apis.stats
        compoundValueOld = _apis.compoundValueOld
    }

    var     revision : UInt16
    var     client : UInt16
    var     cmd : UInt16
    var     parameter : Int16
    var     value : Int32
    var     time : UInt64
    var     stats : (UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8);
    var     compoundValueOld : UInt16
}

/**
 * A typealias to save some typing and make code more readable.
 */
typealias APIStructPtr = UnsafeMutablePointer<APIStruct>

/**
 * This one performs a function similar to that of MyStruct, but changes 
 * made to it are reflected in the C code.  Careful with object lifetime here!
 *
 * It's a struct, but we might just as well make it a class.
 */
struct MyStructUnsafe
{
    init( _p : APIStructPtr )
    {
        pAPIStruct = _p
    }
    
    var time: UInt64 {
        get {
            return pAPIStruct.memory.time
        }
        set( newVal ) {
            pAPIStruct.memory.time = newVal
        }
    }
    var   pAPIStruct: APIStructPtr
}

/**
 * This one takes an APIStruct *.  Works fine regardless of the alignment
 * difference.  Our hand-crafted native Swift structs are not used here.
 */
func swiftCallBack( p: UnsafeMutablePointer<APIStruct> )
{
    print( "Received APIStruct * in swift callback via APIStruct * ...")
    print( "Retrieving APIStruct via subscript...")
    // This is if we want to use the struct imported from C, it's a copy,
    // so changes made to _locAS won't be visible in C code.
    var _locAS:APIStruct = p[0]
    printAPIStruct(_locAS)
    print( "Retrieving APIStruct via .memory...")
    // Again, changes made to this _locAS won't be visible to C
    _locAS = p.memory
    printAPIStruct(_locAS)
    print("Now, in Swift, change its time to 1234567890")
    print("   (do this via a pointer to the original, not a copy!)")
    // And this change will survive and get back to C code
    p[0].time = 12345678901
}

/**
 * This one receives an APIStruct via void *.  Brute force conversion of
 * the argument to UnsafeMutablePointer<MyStruct> won't work when MyStruct
 * is aligned differently enough from APIStruct.
 */
func swiftCallBackVoid( p: UnsafeMutablePointer<Void> )
{
    print( "Received APIStruct * in swift callback via VOID * ...")
    print( "First print MyStruct obtained in a not very safe way: ")
    let _locMS:MyStruct = (UnsafeMutablePointer<MyStruct>(p)).memory;
    printMyStruct(_locMS)
    print("Print MyStruct obtained from void * in a safer way:")
    // Modifications to MyStruct thus obtained won't be visible back in C
    printMyStruct(MyStruct(_apis: (APIStructPtr(p)).memory))
    print( "Print MyStructUnsafe obtained from void * in a safer way: ")
    var _myUnsafe : MyStructUnsafe = MyStructUnsafe(_p: APIStructPtr(p))
    printMyStructUnsafe(_myUnsafe)
    print("Now set its time to 9876543210. ")
    _myUnsafe.time = 9876543210
    printMyStructUnsafe(_myUnsafe)
}

/**
 * Helper to dump an APIStruct.  Print selected info only (time and 3
 * stats members).
 */
func printAPIStruct( s : APIStruct )
{
    print( "Printing APIStruct: ")
    print( "  time: \(s.time)" )
    print( "  stats: \(s.stats.0) \(s.stats.1) \(s.stats.2)" )
    print( "  compoundValueOld: \(s.compoundValueOld)" )
}

/**
 * Helper to dump a MyStruct.  Print selected info only.
 */
func printMyStruct( s: MyStruct )
{
    print( "Printing MyStruct: ")
    print( "  time: \(s.time)" )
    print( "  stats: \(s.stats.0) \(s.stats.1) \(s.stats.2)" )
    print( "  compoundValueOld: \(s.compoundValueOld)" )
}

/**
 * Helper to dump a MyStructUnsafe.  Print only time, which is sufficient
 * for our purposes.
 */
func printMyStructUnsafe( s: MyStructUnsafe )
{
    print( "Printing MyStructUnsafe: ")
    print( "  time: \(s.time)" )
}