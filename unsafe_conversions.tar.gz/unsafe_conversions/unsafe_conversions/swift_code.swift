//
//  swift_code.swift
//  unsafe_conversions
//
//  Created by Anatoli on 10/29/15.
//  Copyright © 2015 Anatoli. All rights reserved.
//

/**
 * This is our native Swift structure.
 *
 * Please note a mismatch in data type of client and cmd between this and APIStruct.
 * This is a contrived example to show what happens if the 2 structures are aligned
 * differently.  Here using the same types would allow even the unsafe conversion to
 * work just fine, but in real life APIStruct might be aligned differently from MyStruct 
 * even if the types were equivalent.  In C you can pack structures for different 
 * alignment.
 */
struct MyStruct
{
    init( _apis : APIStruct)
    {
        revision = _apis.revision
        client = UInt32(_apis.client)  // Adjust accordingly if types are the same
        cmd = UInt32(_apis.cmd)         // Adjust accordingly if types are the same
        parameter = _apis.parameter
        value = _apis.value
        time = _apis.time
        stats = _apis.stats
        compoundValueOld = _apis.compoundValueOld
    }
    
    var     revision : UInt16
    var     client : UInt32          // If UInt16, unsafe conversion will work fine
    var     cmd : UInt32             // Ditto...
    var     parameter : Int16
    var     value : Int32
    var     time : UInt64
    var     stats : (UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8);
    var     compoundValueOld : UInt16
}

/**
 * This one takes an APIStruct *.  Works fine regardless of the alignment
 * difference.
 */
func swiftCallBack( p: UnsafeMutablePointer<APIStruct> )
{
    print( "Received APIStruct * in swift callback via APIStruct * ...")
    let _locMS:APIStruct = p[0]
    printAPIStruct(_locMS)
}

/**
 * This one receives an APIStruct via void *.  Brute force conversion of
 * the argument to UnsafeMutablePointer<MyStruct> won't work when MyStruct
 * is aligned differently enough from APIStruct.
 */
func swiftCallBackVoid( p: UnsafeMutablePointer<Void> )
{
    print( "Received APIStruct * in swift callback via VOID * ...")
    print( "First print MyStruct obtained in a not very safe way: ")
    let _locMS:MyStruct = (UnsafeMutablePointer<MyStruct>(p)).memory;
    printMyStruct(_locMS)
    print("Print MyStruct obtained from void * in a safer way:")
    printMyStruct(MyStruct(_apis: getStructFromVoid(p)))
}

/**
 * Helper to dump an APIStruct.
 */
func printAPIStruct( s : APIStruct )
{
    print( "Printing APIStruct: ")
    print( "  time: \(s.time)" )
    print( "  stats: \(s.stats.0) \(s.stats.1) \(s.stats.2)" )
    print( "  compoundValueOld: \(s.compoundValueOld)" )
}

/**
 * Helper to dump a MyStruct.
 */
func printMyStruct( s: MyStruct )
{
    print( "Printing MyStruct: ")
    print( "  time: \(s.time)" )
    print( "  stats: \(s.stats.0) \(s.stats.1) \(s.stats.2)" )
    print( "  compoundValueOld: \(s.compoundValueOld)" )
}
