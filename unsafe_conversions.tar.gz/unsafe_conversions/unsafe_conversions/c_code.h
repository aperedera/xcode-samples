//
//  c_code.h
//  unsafe_conversions
//
//  Created by Anatoli on 10/29/15.
//  Copyright © 2015 Anatoli. All rights reserved.
//

#ifndef c_code_h
#define c_code_h

#include <stdio.h>

/**
 * This is the C struc being imported.
 */
typedef struct
{
    uint16_t        revision;
    uint16_t        client;
    uint16_t        cmd;
    int16_t         parameter;
    int32_t         value;
    uint64_t        time;
    uint8_t         stats[8];
    uint16_t        compoundValueOld;
} APIStruct;

/** Typedefs & prototypes, self-explanatory.  See c_code.c. */
typedef void(*my_cb_t)(APIStruct *);
void invokeCallBack( my_cb_t );

typedef void(*my_cbv_t)(void *);
void invokeCallBackVoid( my_cbv_t );

APIStruct getStructFromVoid( void *);

#endif /* c_code_h */
